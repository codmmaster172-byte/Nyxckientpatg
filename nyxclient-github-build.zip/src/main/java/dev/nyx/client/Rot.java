package dev.nyx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import java.util.Random;

public class Rot {
    public static final Random R = new Random();

    public static float[] to(Vec3 from, Vec3 to) {
        double dx = to.xCoord - from.xCoord, dy = to.yCoord - from.yCoord, dz = to.zCoord - from.zCoord;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new float[]{yaw, MathHelper.clamp_float(pitch, -90F, 90F)};
    }

    public static Vec3 look(float yaw, float pitch) {
        float f = MathHelper.cos(-yaw * 0.017453292F - (float) Math.PI);
        float f1 = MathHelper.sin(-yaw * 0.017453292F - (float) Math.PI);
        float f2 = -MathHelper.cos(-pitch * 0.017453292F);
        float f3 = MathHelper.sin(-pitch * 0.017453292F);
        return new Vec3(f1 * f2, f3, f * f2);
    }

    public static float wrap(float a) { return MathHelper.wrapAngleTo180_float(a); }

    // Human-like turn: capped step, jitter, snapped to the mouse sensitivity grid
    public static float[] smooth(float cy, float cp, float ty, float tp, float maxStep) {
        float dy = wrap(ty - cy);
        float dp = tp - cp;
        float step = maxStep * (0.6F + R.nextFloat() * 0.4F);
        float dist = (float) Math.hypot(dy, dp);
        if (dist > step && dist > 0) { dy *= step / dist; dp *= step / dist; }
        float j = (float) Settings.num("rot.jitter");
        if (dist > 1.0F) {
            dy += (R.nextFloat() - 0.5F) * j;
            dp += (R.nextFloat() - 0.5F) * j * 0.7F;
        }
        if (Settings.bool("rot.gcd")) {
            float f = Minecraft.getMinecraft().gameSettings.mouseSensitivity * 0.6F + 0.2F;
            float gcd = f * f * f * 8.0F * 0.15F;
            dy = Math.round(dy / gcd) * gcd;
            dp = Math.round(dp / gcd) * gcd;
        }
        return new float[]{cy + dy, MathHelper.clamp_float(cp + dp, -90F, 90F)};
    }

    public static Vec3 closest(AxisAlignedBB bb, Vec3 p) {
        return new Vec3(
            MathHelper.clamp_double(p.xCoord, bb.minX, bb.maxX),
            MathHelper.clamp_double(p.yCoord, bb.minY, bb.maxY),
            MathHelper.clamp_double(p.zCoord, bb.minZ, bb.maxZ));
    }
}
