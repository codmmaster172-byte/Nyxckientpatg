package dev.nyx.client;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C03PacketPlayer.C05PacketPlayerLook;
import net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import java.lang.reflect.Field;

// Outbound handler: swaps the rotation inside movement packets for the silent rotation.
public class PacketRewriter extends ChannelDuplexHandler {
    private static Field fx, fy, fz, fyaw, fpitch, fground, fmoving, frot;
    private static boolean ok = false;
    private static float lastYaw = Float.NaN, lastPitch = Float.NaN;

    static {
        try {
            fx = ReflectionHelper.findField(C03PacketPlayer.class, "x", "field_149479_a");
            fy = ReflectionHelper.findField(C03PacketPlayer.class, "y", "field_149477_b");
            fz = ReflectionHelper.findField(C03PacketPlayer.class, "z", "field_149478_c");
            fyaw = ReflectionHelper.findField(C03PacketPlayer.class, "yaw", "field_149476_e");
            fpitch = ReflectionHelper.findField(C03PacketPlayer.class, "pitch", "field_149473_f");
            fground = ReflectionHelper.findField(C03PacketPlayer.class, "onGround", "field_149474_g");
            fmoving = ReflectionHelper.findField(C03PacketPlayer.class, "moving", "field_149480_h");
            frot = ReflectionHelper.findField(C03PacketPlayer.class, "rotating", "field_149481_i");
            ok = true;
        } catch (Throwable t) { ok = false; }
    }

    @Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
        try {
            if (ok && msg instanceof C03PacketPlayer) msg = handle((C03PacketPlayer) msg);
        } catch (Throwable ignored) {}
        super.write(ctx, msg, promise);
    }

    private Object handle(C03PacketPlayer pkt) throws Exception {
        boolean rotating = frot.getBoolean(pkt);
        boolean moving = fmoving.getBoolean(pkt);
        if (rotating) {
            if (RotationManager.active) {
                fyaw.setFloat(pkt, RotationManager.yaw);
                fpitch.setFloat(pkt, RotationManager.pitch);
            }
            lastYaw = fyaw.getFloat(pkt);
            lastPitch = fpitch.getFloat(pkt);
            return pkt;
        }
        if (RotationManager.active && (RotationManager.yaw != lastYaw || RotationManager.pitch != lastPitch)) {
            lastYaw = RotationManager.yaw;
            lastPitch = RotationManager.pitch;
            boolean g = fground.getBoolean(pkt);
            if (moving) {
                return new C06PacketPlayerPosLook(fx.getDouble(pkt), fy.getDouble(pkt), fz.getDouble(pkt), lastYaw, lastPitch, g);
            }
            return new C05PacketPlayerLook(lastYaw, lastPitch, g);
        }
        return pkt;
    }
}
