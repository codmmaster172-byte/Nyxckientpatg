package dev.nyx.client;

import net.minecraft.client.entity.EntityPlayerSP;

// Holds the "server-side" rotation. The camera stays untouched; packets carry this rotation instead.
public class RotationManager {
    public static volatile boolean active = false;
    public static volatile float yaw, pitch;
    public static float camYaw;
    public static boolean swapped = false;
    private static boolean requested = false;

    public static float[] cur(EntityPlayerSP p) {
        return active ? new float[]{yaw, pitch} : new float[]{p.rotationYaw, p.rotationPitch};
    }

    public static void request(EntityPlayerSP p, float ty, float tp, float step) {
        if (!active) { yaw = p.rotationYaw; pitch = p.rotationPitch; active = true; }
        float[] n = Rot.smooth(yaw, pitch, ty, tp, step);
        yaw = n[0];
        pitch = n[1];
        requested = true;
    }

    // call once per client tick after the modules ran: eases back to the camera when nobody asked for rotation
    public static void tick(EntityPlayerSP p) {
        if (active && !requested) {
            float[] n = Rot.smooth(yaw, pitch, p.rotationYaw, p.rotationPitch, (float) Settings.num("rot.returnSpeed"));
            yaw = n[0];
            pitch = n[1];
            if (Math.abs(Rot.wrap(yaw - p.rotationYaw)) < 1.5F && Math.abs(pitch - p.rotationPitch) < 1.5F) active = false;
        }
        requested = false;
    }

    public static void reset() { active = false; swapped = false; requested = false; }

    // Movement fix part 1: physics run with the silent yaw (swapped in at the start of the player tick)
    public static void begin(EntityPlayerSP p) {
        if (active && Settings.bool("rot.moveFix")) {
            camYaw = p.rotationYaw;
            p.rotationYaw = yaw;
            swapped = true;
        }
    }

    public static void end(EntityPlayerSP p) {
        if (swapped) {
            p.rotationYaw = camYaw;
            p.prevRotationYaw = camYaw;
            swapped = false;
        }
    }

    // Movement fix part 2: remap WASD so the real walking direction still matches what the player pressed
    public static void fixInput(net.minecraft.util.MovementInput in, boolean sneaking) {
        if (!swapped) return;
        float f = in.moveForward, s = in.moveStrafe;
        if (f == 0 && s == 0) return;
        float scale = sneaking ? 0.3F : 1.0F;
        float desired = camYaw + (float) Math.toDegrees(Math.atan2(-s, f));
        float rel = Rot.wrap(desired - yaw);
        float bestDiff = Float.MAX_VALUE, bf = 0, bs = 0;
        for (int fi = -1; fi <= 1; fi++) {
            for (int si = -1; si <= 1; si++) {
                if (fi == 0 && si == 0) continue;
                float ang = (float) Math.toDegrees(Math.atan2(-si, fi));
                float diff = Math.abs(Rot.wrap(ang - rel));
                if (diff < bestDiff) { bestDiff = diff; bf = fi; bs = si; }
            }
        }
        in.moveForward = bf * scale;
        in.moveStrafe = bs * scale;
    }
}
