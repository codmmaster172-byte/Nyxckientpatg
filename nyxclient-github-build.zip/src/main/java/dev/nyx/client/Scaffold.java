package dev.nyx.client;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

public class Scaffold {
    public boolean enabled = false;
    private int delay = 0;
    private int origSlot = -1;

    private boolean usable(ItemStack s) {
        if (s == null || s.stackSize <= 0 || !(s.getItem() instanceof ItemBlock)) return false;
        Block b = ((ItemBlock) s.getItem()).getBlock();
        return b.isFullCube() && !(b instanceof BlockFalling) && !(b instanceof ITileEntityProvider);
    }

    private int findSlot(EntityPlayerSP p) {
        if (!Settings.bool("sc.autoSwitch")) {
            return usable(p.inventory.getCurrentItem()) ? p.inventory.currentItem : -1;
        }
        if (usable(p.inventory.getCurrentItem())) return p.inventory.currentItem;
        for (int i = 0; i < 9; i++) if (usable(p.inventory.getStackInSlot(i))) return i;
        return -1;
    }

    private void restoreSlot(Minecraft mc) {
        if (origSlot != -1 && mc.thePlayer != null) {
            mc.thePlayer.inventory.currentItem = origSlot;
            mc.playerController.updateController();
        }
        origSlot = -1;
    }

    // returns true while it is handling rotation/placement (KillAura pauses then)
    public boolean tick(Minecraft mc) {
        if (!enabled) { restoreSlot(mc); return false; }
        if (mc.currentScreen != null) return false;
        EntityPlayerSP p = mc.thePlayer;

        BlockPos below = new BlockPos(p.posX, p.posY - 1.0, p.posZ);
        if (!mc.theWorld.isAirBlock(below)) return false;

        int slot = findSlot(p);
        if (slot == -1) return false;

        if (delay > 0) delay--;

        Vec3 eye = p.getPositionEyes(1.0F);
        double reach = Settings.num("sc.reach");

        // 1) place with the rotation the server already has: the ray must really hit a face that leads into 'below'
        float[] base = RotationManager.cur(p);
        Vec3 look = Rot.look(base[0], base[1]);
        Vec3 end = eye.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eye, end);
        if (delay <= 0 && mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK
                && mop.getBlockPos().offset(mop.sideHit).equals(below)) {
            if (origSlot == -1) origSlot = p.inventory.currentItem;
            if (p.inventory.currentItem != slot) {
                p.inventory.currentItem = slot;
                mc.playerController.updateController();
            }
            if (mc.playerController.onPlayerRightClick(p, mc.theWorld, p.inventory.getCurrentItem(),
                    mop.getBlockPos(), mop.sideHit, mop.hitVec)) {
                if (Settings.bool("sc.swing")) p.swingItem();
            }
            int lo = (int) Math.min(Settings.num("sc.delayMin"), Settings.num("sc.delayMax"));
            int hi = (int) Math.max(Settings.num("sc.delayMin"), Settings.num("sc.delayMax"));
            delay = lo + Rot.R.nextInt(hi - lo + 1);
        }

        // 2) choose the face to aim at for the next packet
        EnumFacing[] order = {EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST, EnumFacing.DOWN};
        BlockPos clickPos = null;
        EnumFacing face = null;
        for (EnumFacing f : order) {
            BlockPos nb = below.offset(f);
            if (!mc.theWorld.isAirBlock(nb) && !mc.theWorld.getBlockState(nb).getBlock().getMaterial().isLiquid()) {
                clickPos = nb;
                face = f.getOpposite();
                break;
            }
        }
        if (clickPos == null) return false;

        double jx = face.getFrontOffsetX() == 0 ? (Rot.R.nextDouble() - 0.5) * 0.6 : 0;
        double jy = face.getFrontOffsetY() == 0 ? (Rot.R.nextDouble() - 0.5) * 0.6 : 0;
        double jz = face.getFrontOffsetZ() == 0 ? (Rot.R.nextDouble() - 0.5) * 0.6 : 0;
        Vec3 aim = new Vec3(
            clickPos.getX() + 0.5 + face.getFrontOffsetX() * 0.5 + jx,
            clickPos.getY() + 0.5 + face.getFrontOffsetY() * 0.5 + jy,
            clickPos.getZ() + 0.5 + face.getFrontOffsetZ() * 0.5 + jz);

        float[] want = Rot.to(eye, aim);
        float lo = (float) Math.min(Settings.num("sc.turnMin"), Settings.num("sc.turnMax"));
        float hi = (float) Math.max(Settings.num("sc.turnMin"), Settings.num("sc.turnMax"));
        float step = lo + Rot.R.nextFloat() * (hi - lo);

        if (Settings.bool("sc.silent")) {
            RotationManager.request(p, want[0], want[1], step);
        } else {
            float[] n = Rot.smooth(p.rotationYaw, p.rotationPitch, want[0], want[1], step);
            p.rotationYaw = n[0];
            p.rotationPitch = n[1];
        }
        return true;
    }
}
