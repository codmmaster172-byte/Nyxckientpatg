package dev.nyx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class Targets {
    private static char nameColor(EntityPlayer e) {
        String s = e.getDisplayName().getFormattedText();
        for (int i = 0; i < s.length() - 1; i++) {
            if (s.charAt(i) == '\u00a7') {
                char c = Character.toLowerCase(s.charAt(i + 1));
                if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')) return c;
            }
        }
        return 0;
    }

    private static int armorColor(EntityPlayer e) {
        ItemStack st = e.getCurrentArmor(2);
        if (st != null && st.getItem() instanceof ItemArmor) {
            ItemArmor a = (ItemArmor) st.getItem();
            if (a.getArmorMaterial() == ItemArmor.ArmorMaterial.LEATHER) {
                int c = a.getColor(st);
                if (c != 10511680) return c; // default undyed leather
            }
        }
        return -1;
    }

    public static boolean isTeammate(EntityPlayerSP p, EntityPlayer e) {
        if (Settings.bool("team.scoreboard") && e.isOnSameTeam(p)) return true;
        if (Settings.bool("team.nameColor")) {
            char a = nameColor(p), b = nameColor(e);
            if (a != 0 && a == b && a != 'f' && a != '7') return true;
        }
        if (Settings.bool("team.armorColor")) {
            int a = armorColor(p), b = armorColor(e);
            if (a != -1 && a == b) return true;
        }
        return false;
    }

    public static boolean isFriend(EntityPlayer e) {
        String list = Settings.str("team.friends");
        if (list.isEmpty()) return false;
        for (String n : list.split(",")) if (n.trim().equalsIgnoreCase(e.getName())) return true;
        return false;
    }

    public static boolean isBot(Minecraft mc, EntityPlayer e) {
        if (!Settings.bool("team.antiBot")) return false;
        if (mc.getNetHandler() == null || mc.getNetHandler().getPlayerInfo(e.getUniqueID()) == null) return true;
        if (!e.getName().matches("[A-Za-z0-9_]{1,16}")) return true;
        return e.ticksExisted < (int) Settings.num("team.botTicks");
    }

    public static boolean isValid(Minecraft mc, EntityPlayerSP p, EntityPlayer e) {
        if (e == p || e.isDead || e.getHealth() <= 0) return false;
        if (e.isInvisible() && !Settings.bool("ka.invisible")) return false;
        if (isFriend(e) || isTeammate(p, e) || isBot(mc, e)) return false;
        return true;
    }
}
